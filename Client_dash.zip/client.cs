$remapDivision[$remapCount] = "aod";
$remapName[$remapCount] = "Dash";
$remapCmd[$remapCount] = "Dash";
$remapName[$remapCount++] = "Coordinates";
$remapCmd[$remapCount] = "Coordinates";
$remapName[$remapCount++] = "Push Item Up";
$remapCmd[$remapCount] = "PushItemUp";
$remapName[$remapCount++] = "Push Item Down";
$remapCmd[$remapCount] = "PushItemDown";
$remapName[$remapCount++] = "Compress Items";
$remapCmd[$remapCount] = "compressitems";
$remapName[$remapCount++] = "Bloodspray Spell";
$remapCmd[$remapCount] = "bloodspray";
$remapName[$remapCount++] = "Bloodbombs Spell";
$remapCmd[$remapCount] = "bloodbombs";
$remapName[$remapCount++] = "OathBreakerLightning Spell";
$remapCmd[$remapCount] = "oathbreaker";
$remapCount++;

function dash(%a) {
	if(!%a){
        commandtoserver('cast',dash);
		return;
	}
}

function coordinates(%a) {
	if(!%a){
        %j = serverconnection.getcontrolobject().getposition();
		commandtoserver('messagesent',%j);
		//%x = getwords(%j,0,0);
		//%y = getwords(%j,1,1);
		//%z = getwords(%j,2,2);
		//%posx = mfloatlength(%x,0);
		//%posy = mfloatlength(%y,0);
		//%posz = mfloatlength(%z,0);
		//commandtoserver('messagesent',%posx SPC %posy SPC %posz);
		return;
	}
}

function pushitemdown(%a) {
	if(!%a){
		commandtoserver('pushitemdown');
		return;
	}
}

function pushitemup(%a) {
	if(!%a){
		commandtoserver('pushitemup');
		return;
	}
}

function compressitems(%a) {
	if(!%a){
		commandtoserver('compressitems');
		return;
	}
}

function bloodspray(%a) {
	if(!%a){
		commandtoserver('autocast',bloodspray);
		return;
	}
}

function bloodbombs(%a) {
	if(!%a){
		commandtoserver('autocast',bloodbombs);
		return;
	}
}

function oathbreaker(%a) {
	if(!%a){
		commandtoserver('autocast',oathbreakerlightning);
		return;
	}
}

function removeShake()
{
	%count = getDataBlockGroupSize();
	for(%I=0;%I<%count;%I++)
	{
		%d = getDataBlock(%i);
		if(%d.getClassName() $= "ExplosionData")
		{
			%effect++;
			%d.sbA = %d.camShakeAmp;
			%d.sbF = %d.camShakeFreq;
			%d.camShakeAmp = "0 0 0";
			%d.camShakeFreq = "0 0 0";
		}
	}
	echo("Removed camera shake on #"@ %effect*1 @" weapons.");
}

function oathbreakerhp(%number)
{
	echo("\c2oathbreaker phase 1.5:\c4" SPC %number * 0.8 SPC "\c5HP");
	echo("\c2oathbreaker phase 2:\c4" SPC %number * 0.6 SPC "\c5HP");
	echo("\c2oathbreaker phase 3:\c4" SPC %number * 0.3 SPC "\c5HP");
}

//credits to queuenard for autobuy

function buy(%amount)
{
	buystuff(0, %amount);
}

function buystuff(%i, %amount)
{
	if(%i >= %amount)
	{
		return;
	}

	commandtoserver('droptool', $currscrolltoolslot);
	commandtoserver('activatestuff');
	commandtoserver('purchaseitem');
	schedule(100, 0, buystuff, %i+1, %amount);
}

if(!isObject(positionGUI))
{
	exec("./positionGUI.gui");
	playGUI.add("positionGUI");
}


if(!$pref::HUD::positionGUIupdateSpeed)
	$pref::HUD::positionGUIupdateSpeed = 32;

function updatePositionGUI()
{
	if(isObject(serverConnection))
		if(isObject(%player = serverConnection.getControlObject()))
		{
			if(%player.getClassName() $= "Player")
			{
				%direction = %player.getforwardvector();
				%position = %player.getPosition();
				%speed = %player.getVelocity();
				%scale = %player.getScale();
			}
			
			else if(%player.getClassName() $= "Camera")
			{
				if(%player.isOrbitMode())
				{
					%direction = %player.getforwardvector();
					%position = %player.getOrbitPoint();
					%player = %player.getOrbitObject();
					%scale = %player.getScale();
				}
				else
					%position = %player.getTransform();
				
				if(isObject(%player))
					%speed = %player.getVelocity();
			}
				
			
			%x = mFloatLength(getWord(%position, 0), 1);
			%y = mFloatLength(getWord(%position, 1), 1);
			%z = mFloatLength(getWord(%position, 2), 1);
			
			
			
			%sx = mFloatLength(getWord(%speed, 0), 1);
			%sy = mFloatLength(getWord(%speed, 1), 1);
			%sz = mFloatLength(getWord(%speed, 2), 1);
						
			
			
			%xdirection = getWord(%direction, 0);
			%ydirection = getWord(%direction, 1);



			%scale = mFloatLength(getWord(%scale, 0), 3);

			if(mAbs(%sx) > 28 || mAbs(%sy) > 28 || mAbs(%sz) > 28)
				%velColor = "ff2222";

			else
				%velColor = "ffffff";

			if(%ydirection > 0.7 & %ydirection < 1.25)
			{
				%compass = "NORTH";
			}
			if(%xdirection > 0.7 & %xdirection < 1.25)
			{
				%compass = "EAST";
			}
			if(%xdirection < -0.7 & %xdirection > -1.25)
			{
				%compass = "WEST";
			}
			if(%ydirection < -0.7 & %ydirection > -1.25)
			{
				%compass = "SOUTH";
			}

			if(%scale == 1)
			{
				%growth = 0;
			}
			else
			{
				%growth = mfloatlength(((%scale/1) - 1) * 40,0);
			}
			
			%aodservercheck = serverconnection.getaddress();
			if(%aodservercheck $= "45.77.159.176:28000")
			{
				%server = "Server: US-E";
			}
			else if(%aodservercheck $= "95.179.157.182:28000")
			{
				%server = "Server: EU-NL";
			}
			if(%aodservercheck $= "45.77.159.176:28000" || %aodservercheck $= "95.179.157.182:28000")
			{
				positionGUIText.setText("<font:verdana:15><color:ffffff>" @ %server NL "<br>" @ %x SPC %y SPC %z NL "<br><color:" @ %velColor @ ">" @ %sx SPC %sy SPC %sz NL "<br><color:ffffff>" @ %scale SPC "<font:verdana:12>(Growth: <color:00ffff>" @ %growth @ "<color:ffffff>x)" NL "<br><font:verdana:14>" @ %compass);
			}
			else
			{
				positionGUIText.setText("<font:verdana:15><color:ffffff>" @ %x SPC %y SPC %z NL "<br><color:" @ %velColor @ ">" @ %sx SPC %sy SPC %sz NL "<br><color:ffffff>" @ %scale NL "<br><font:verdana:14>" @ %compass);
			}
		}
		
	schedule($pref::HUD::positionGUIupdateSpeed, positionGUI, updatePositionGUI);
}

updatePositionGUI();



